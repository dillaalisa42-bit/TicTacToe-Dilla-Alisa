package Tugas_3;

public class SegitigaSamaKaki extends BangunDatar {

    private double alas;
    private double tinggi;
    private double sisiMiring;

    public SegitigaSamaKaki(double alas, double tinggi, double sisiMiring) {
        super("Segitiga Sama Kaki");
        this.alas = alas;
        this.tinggi = tinggi;
        this.sisiMiring = sisiMiring;
    }

    @Override
    public double hitungLuas() {
        return 0.5 * alas * tinggi;
    }

    @Override
    public double hitungKeliling() {
        return alas + (2 * sisiMiring);
    }

    public double getAlas() {
        return alas;
    }

    public double getTinggi() {
        return tinggi;
    }

    public double getSisiMiring() {
        return sisiMiring;
    }
}