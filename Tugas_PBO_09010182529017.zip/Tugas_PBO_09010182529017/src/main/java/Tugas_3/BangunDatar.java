package Tugas_3;

public abstract class BangunDatar {

    protected String nama;

    public BangunDatar(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return nama;
    }

    public abstract double hitungLuas();

    public abstract double hitungKeliling();

    public void tampilkanNama() {
        System.out.println("Nama bangun: " + nama);
    }
}