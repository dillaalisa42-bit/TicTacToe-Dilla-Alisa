package Tugas_3;

public class Main {

    public static void main(String[] args) {

        // Membuat objek Segitiga Sama Kaki
        SegitigaSamaKaki segitiga =
                new SegitigaSamaKaki(10, 8, 9);

        // Membuat objek Persegi Panjang
        PersegiPanjang persegiPanjang =
                new PersegiPanjang(12, 5);

        // Membuat objek Lingkaran
        Lingkaran lingkaran =
                new Lingkaran(7);

        System.out.println("=================================");
        System.out.println("       PROGRAM BANGUN DATAR      ");
        System.out.println("=================================");

        System.out.println();
        segitiga.tampilkanNama();
        System.out.println("Alas       : " + segitiga.getAlas());
        System.out.println("Tinggi     : " + segitiga.getTinggi());
        System.out.println("Sisi Miring: " + segitiga.getSisiMiring());
        System.out.println("Luas       : " + segitiga.hitungLuas());
        System.out.println("Keliling   : " + segitiga.hitungKeliling());

        System.out.println();
        persegiPanjang.tampilkanNama();
        System.out.println("Panjang    : " + persegiPanjang.getPanjang());
        System.out.println("Lebar      : " + persegiPanjang.getLebar());
        System.out.println("Luas       : " + persegiPanjang.hitungLuas());
        System.out.println("Keliling   : " + persegiPanjang.hitungKeliling());

        System.out.println();
        lingkaran.tampilkanNama();
        System.out.println("Jari-jari  : " + lingkaran.getJariJari());
        System.out.println("Luas       : " + lingkaran.hitungLuas());
        System.out.println("Keliling   : " + lingkaran.hitungKeliling());

        System.out.println();
        System.out.println("=================================");
        System.out.println("       PROGRAM SELESAI           ");
        System.out.println("=================================");
    }
}