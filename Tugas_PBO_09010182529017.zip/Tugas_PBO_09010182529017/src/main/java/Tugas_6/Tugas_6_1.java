package Tugas_6;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Tugas_6_1 {

    public static void main(String[] args) {

        BufferedReader dataIn =
                new BufferedReader(new InputStreamReader(System.in));

        double nilai1 = 0;
        double nilai2 = 0;
        double nilai3 = 0;
        double rataRata;

        try {

            System.out.print("Masukkan nilai ujian 1: ");
            nilai1 = Double.parseDouble(dataIn.readLine());

            System.out.print("Masukkan nilai ujian 2: ");
            nilai2 = Double.parseDouble(dataIn.readLine());

            System.out.print("Masukkan nilai ujian 3: ");
            nilai3 = Double.parseDouble(dataIn.readLine());

        } catch (IOException e) {

            System.out.println("Error!");

        }

        rataRata = (nilai1 + nilai2 + nilai3) / 3;

        System.out.println("Rata-rata = " + rataRata);

        if (rataRata >= 60) {

            System.out.println(":)");

        } else {

            System.out.println(":-(");
        }
    }
}