import javax.swing.JOptionPane;

public class Tugas_6_4 {

    public static void main(String[] args) {

        int angka;
        int pangkat;
        int hasil = 1;
        int i = 1;

        angka = Integer.parseInt(
                JOptionPane.showInputDialog(
                        "Masukkan angka:"
                )
        );

        pangkat = Integer.parseInt(
                JOptionPane.showInputDialog(
                        "Masukkan pangkat:"
                )
        );

        while (i <= pangkat) {

            hasil = hasil * angka;

            i++;
        }

        JOptionPane.showMessageDialog(
                null,
                angka + "^" + pangkat + " = " + hasil
        );
    }
}