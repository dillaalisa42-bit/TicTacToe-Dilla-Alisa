public class Tugas_6_3 {

    public static void main(String[] args) {

        int i = 1;

        while (i <= 100) {

            System.out.println(i + ". bila");

            i++;
        }
    }
}