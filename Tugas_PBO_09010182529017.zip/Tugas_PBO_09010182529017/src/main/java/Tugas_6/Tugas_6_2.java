import javax.swing.JOptionPane;

public class Tugas_6_2 {

    public static void main(String[] args) {

        int angka;

        angka = Integer.parseInt(
                JOptionPane.showInputDialog(
                        "Masukkan angka 1-10:"
                )
        );

        if (angka == 1) {

            JOptionPane.showMessageDialog(null, "Satu");

        } else if (angka == 2) {

            JOptionPane.showMessageDialog(null, "Dua");

        } else if (angka == 3) {

            JOptionPane.showMessageDialog(null, "Tiga");

        } else if (angka == 4) {

            JOptionPane.showMessageDialog(null, "Empat");

        } else if (angka == 5) {

            JOptionPane.showMessageDialog(null, "Lima");

        } else if (angka == 6) {

            JOptionPane.showMessageDialog(null, "Enam");

        } else if (angka == 7) {

            JOptionPane.showMessageDialog(null, "Tujuh");

        } else if (angka == 8) {

            JOptionPane.showMessageDialog(null, "Delapan");

        } else if (angka == 9) {

            JOptionPane.showMessageDialog(null, "Sembilan");

        } else if (angka == 10) {

            JOptionPane.showMessageDialog(null, "Sepuluh");

        } else {

            JOptionPane.showMessageDialog(null, "Invalid number");
        }
    }
}   