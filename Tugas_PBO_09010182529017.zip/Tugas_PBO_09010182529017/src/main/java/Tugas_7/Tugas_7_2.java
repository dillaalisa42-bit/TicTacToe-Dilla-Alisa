public class Tugas_7_2 {

    public static void main(String[] args) {

        String days[] = {
            "Monday",
            "Tuesday",
            "Wednesday",
            "Thursday",
            "Friday",
            "Saturday",
            "Sunday"
        };

        int i = 0;

        do {

            System.out.println(days[i]);

            i++;

        } while (i < days.length);
    }
}