package Tugas_10;

public class Main {
    public static void main(String[] args) {

        Buku_alamat data1 = new Buku_alamat("", "", "", "");
        Buku_alamat data2 = new Buku_alamat("", "", "", "");
        Buku_alamat data3 = new Buku_alamat("", "", "", "");
        Buku_alamat data4 = new Buku_alamat("", "", "", "");
        Buku_alamat data5 = new Buku_alamat("", "", "", "");

        data1.setNama("Nabila Julyanti");
        data1.setAlamat("Palembang");
        data1.setNomorTelepon("08386092158");
        data1.setAlamatEmail("Nabila@gmail.com");

        data2.setNama("Andi");
        data2.setAlamat("Jakarta");
        data2.setNomorTelepon("082345678901");
        data2.setAlamatEmail("andi@gmail.com");

        data3.setNama("Budi");
        data3.setAlamat("Bandung");
        data3.setNomorTelepon("083456789012");
        data3.setAlamatEmail("budi@gmail.com");

        data4.setNama("Siti");
        data4.setAlamat("Surabaya");
        data4.setNomorTelepon("084567890123");
        data4.setAlamatEmail("siti@gmail.com");

        data5.setNama("Dina");
        data5.setAlamat("Medan");
        data5.setNomorTelepon("085678901234");
        data5.setAlamatEmail("dina@gmail.com");

        System.out.println("===== DATA BUKU ALAMAT =====");

        System.out.println("\nData 1");
        System.out.println("Nama          : " + data1.getNama());
        System.out.println("Alamat        : " + data1.getAlamat());
        System.out.println("Nomor Telepon : " + data1.getNomorTelepon());
        System.out.println("E-Mail        : " + data1.getAlamatEmail());

        System.out.println("\nData 2");
        System.out.println("Nama          : " + data2.getNama());
        System.out.println("Alamat        : " + data2.getAlamat());
        System.out.println("Nomor Telepon : " + data2.getNomorTelepon());
        System.out.println("E-Mail        : " + data2.getAlamatEmail());

        System.out.println("\nData 3");
        System.out.println("Nama          : " + data3.getNama());
        System.out.println("Alamat        : " + data3.getAlamat());
        System.out.println("Nomor Telepon : " + data3.getNomorTelepon());
        System.out.println("E-Mail        : " + data3.getAlamatEmail());

        System.out.println("\nData 4");
        System.out.println("Nama          : " + data4.getNama());
        System.out.println("Alamat        : " + data4.getAlamat());
        System.out.println("Nomor Telepon : " + data4.getNomorTelepon());
        System.out.println("E-Mail        : " + data4.getAlamatEmail());

        System.out.println("\nData 5");
        System.out.println("Nama          : " + data5.getNama());
        System.out.println("Alamat        : " + data5.getAlamat());
        System.out.println("Nomor Telepon : " + data5.getNomorTelepon());
        System.out.println("E-Mail        : " + data5.getAlamatEmail());
    }
}
