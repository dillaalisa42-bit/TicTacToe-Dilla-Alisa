public class Tugas_4_2 {

    public static void main(String[] args) {

        // Deklarasi dan inisialisasi tiga angka
        int number1 = 10;
        int number2 = 20;
        int number3 = 45;

        // Menghitung nilai rata-rata
        int rataRata = (number1 + number2 + number3) / 3;

        // Menampilkan angka
        System.out.println("number 1 = " + number1);
        System.out.println("number 2 = " + number2);
        System.out.println("number 3 = " + number3);

        // Menampilkan hasil rata-rata
        System.out.println("Rata-rata = " + rataRata);
    }
}