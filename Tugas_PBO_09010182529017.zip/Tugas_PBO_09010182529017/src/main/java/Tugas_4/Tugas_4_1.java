public class Tugas_4_1 {

    public static void main(String[] args) {

        // Deklarasi dan inisialisasi variabel
        int number = 10;
        char letter = 'a';
        boolean result = true;
        String str = "hello";

        // Menampilkan nilai variabel
        System.out.println("Number = " + number);
        System.out.println("letter = " + letter);
        System.out.println("result = " + result);
        System.out.println("str = " + str);
    }
}