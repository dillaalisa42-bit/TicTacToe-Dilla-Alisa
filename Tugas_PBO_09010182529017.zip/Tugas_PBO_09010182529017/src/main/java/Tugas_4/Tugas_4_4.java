package Tugas_4;

public class Tugas_4_4 {

    public static void main(String[] args) {

        int a = 100;
        int b = 2;
        int c = 2;
        int d = 2;
        int e = 5;
        int f = 10;
        int g = 2;
        int h = 3;
        int i = 4;

        int hasil = ((a / (b * c * d)) - e + f - (g * h) + i);

        System.out.println("Hasil = " + hasil);
    }
}
